## Reference Works

*BA*	\= *Biblioteca de al-Andalus*, ed. Jorge Lirola Delgado and José Miguel Puerta Vílchez, 8 vols. (1–7 \+ Appendix \[= A\]) \+ Index, Enciclopedia de la cultura andalusí 1 (Almería: Fundación Ibn Tufayl de Estudios Árabes, 2004–2013).  
*DMBI* 	\= *Dāʾirat-i Maʿārif-i Bozorg-i Islāmī* Online edition, ed. Aḥmad Pākatčī *et al*. Tehran: 1367– Š/1988–. URL:[https://www.cgie.org.ir/](https://www.cgie.org.ir/).   
*EI*1 	\= *E.J. Brill’s First Encyclopaedia of Islam, 1913–1936*, eds. Martijn Th. Houtsma, Arent J. Wensinck, Thomas W. Arnold, Willi Heffening, and Évariste Lévi-Provençal, 9 vols., reprint (Leiden: Brill, 1987).   
*EI*2	\= *Encyclopaedia of Islam, New Edition*, Online Edition, eds. Peri J. Bearman, Thierry Bianquis, Clifford E. Bosworth, Emeri van Donzel, and Wolfhart P. Heinrichs (Leiden: Brill Online, 1960–2006): URL:[https://referenceworks.brill.com/display/db/eieo](https://referenceworks.brill.com/display/db/eieo).   
*EI*3	\= *Encyclopaedia of Islam,* THREE Online, eds. Kate Fleet, Gudrun Krämer, Denis Matrinage, John Nawas, and Devin J. Stewart (Leiden: Brill Online, 2007–). URL:[https://referenceworks.brill.com/display/package/eio](https://referenceworks.brill.com/display/package/eio).   
*EIr*	\= *Encyclopædia Iranica* Online, ed. Ehsan Yarshater and Greg Elmore (New York: Encyclopædia Iranica Foundation, 1996–2017). URL:[https://www.iranicaonline.org/](http://www.iranicaonline.org/).    
*PUA*	\= *Prosopografía de los ulemas de al-Andalus*, eds. María Luisa Ávila, Luis Molina, Mayte Penelas, and María López Fernández (Granada: Consejo Superior de Investigaciones Científicas, 2006–). URL:[https://www.eea.csic.es/pua/index.php/](https://www.eea.csic.es/pua/index.php/).  
*TDVİA*	\= *Türkiye Diyanet Vakfı İslâm Ansiklopedisi* Online, ed. Ahmet Tokaploǧlu *et al*. Istanbul: Türkiye Diyanet Vakfı, 2016–. URL:[https://islamansiklopedisi.org.tr/](https://islamansiklopedisi.org.tr/).

## Manuscripts

al-Asad, Naṣr al-Dīn. *al-Fihrist al-šāmil li-l-turāṯ al-ʿArabī al-Islāmī al-maḫṭūṭ. ʿUlūm al-Qurʾān: Maḫṭūṭāṭ al-qirāʾāt*, second revised edition (Amman: Muʾassasat Āl al-Bayt and al-Muǧammaʿ al-Malikī li-Buḥūṯ al-Ḥaḍārah al-Islāmiyyah, 1414/1994).  
Brockelmann, Carl. *Geschichte der arabischen Litteratur*, 2 vols. \+ Supplements, second edition (Leiden: Brill, 1943–1947), in English as *History of Arabic Literature*, tr. Joep Lameer, Handbook of Oriental Studies. Section One – The Near and Middle East 117/1–2,S1–3 (Leiden: Brill, 2016–2019); hereafter cited as *GAL*, according to the German/English editions. URL:[https://referenceworks.brill.com/display/db/broo](https://referenceworks.brill.com/display/db/broo).    
Otto, Pretzl. “Die Wissenschaft der Koranlesung (*ʿilm al-qirāʾāt*), ihre literarischen Quellen und ihr Aussprachegrundlangen (*uṣūl*),” *Islamica* (Leipzig) 6 (1934):1–47, 230–46, 290–331; hereafter cited as “Die Wissenschaft der Koranlesung.”  
Sezgin, Fuat. *Geschichte des arabischen Schrifttums, Band 1: Qurʾānwissenschaften, Ḥadīṯ, Geschichte, Fiqh, Dogmatik, Mystik bis ca. 430 H.* (Leiden: Brill, 1967); hereafter cited as *GAS*.

## Bibliographic Studies

al-Ḥāfiẓ, Muḥammad Muṭīʿ. *al-Qirāʾāt wa-kibār al-qurrāʾ fī Dimašq min al-qarn al-awwal al-hiǧrī ḥattā al-ʿaṣr al-ḥāḍir* (Damascus: Dār al-Fikr, 1424/2003).  
Ḥamdān, ʿUmar. *Muʿǧam muṣannafāt ʿulūm al-Qurʾān al-Karīm* (Beirut: Dār Ibn Ḥazm, 1439/2018); hereafter cited as *MM*.  
Ḥamdān,ʿUmar. *Adab ʿilm al-qirāʾāt* (= *Die Fachliteratur der Koranlesungen*) (Tübingen: Eberhard Karls Universität Lehrstuhl für Koranwissenschaften, Zentrum für Islamische Theologie, 1425/2023); hereafter cited as *Adab*.  
Ḥamītū, ʿAbd al-Hādī ʿAbd Allāh. *Muʿǧam muʾallafāt al-ḥāfiẓ Abī ʿAmr al-Dānī (tuwufiyya 444 hiǧrī)* (Riyadh: Maktabat al-Malik Fahd al-Waṭaniyyah, 1432/2001); hereafter cited as *Muʿǧam muʿallafāt al-Dānī*.  
Ḥamītū, ʿAbd al-Hādī ʿAbd Allāh. *Muʿǧam šuyūḫ al-ḥāfiẓ Abī ʿAmr al-Dānī imām al-qurrāʾ bi-l-Maġrib wa-l-ʾAndalus: Ǧamʿ wa-naqd li-mā waqaʿa fī tarāǧimihim min aḫṭāʾ al-muʾallifīn wa-l-muḥaqqiqīn* (Āsafī, Morocco: al-Ǧamaʿiyyah al-Maġribiyyah li-Asātiḏat al-Tarbiyah al-Islāmiyyah, 1421/2000); hereafter cited as *Muʿǧam šuyūḫ al-Dānī*.  
Kanūnī, ʿAbd al-Salām Aḥmad. *al-Madrasah al-Qurʾāniyyah fī al-Maġrib min al-fatḥ al-Islāmī ilā Ibn ʿAṭiyyah* (Rabat: Makatabat al-Maʿārif, 1401/1981); hereafter cited as *MQM*.  
Šalabī, Hind. *al-Qirāʾāt bi-Ifrīqiyyah min al-fatḥ ilā muntaṣif al-qarn al-ḫāmis al-hiǧrī* (Tunis: al-Dār al-ʿArabiyyah li-l-Kitāb, 1983\) // ([link](https://archive.org/details/20200424_20200424_1300/mode/1up))  
Sālim Muḥaysin, Muḥammad. *Muʿǧam ḥuffāẓ al-Qurʾān ʿabr al-tārīḫ*, 2 vols. (Beirut: Dār al-Ǧīl, 1412/1992); hereafter cited as *Muʿǧam ḥuffāẓ*.  
Walad Ubbāh, Muḥammad Muḫtār. *Tarīḫ al-qirāʾāt fī al-Mašriq wa-l-Maġrib* (Rabat: UNESCO, 1422/2001); hereafter cited as *Tārīḫ al-qirāʾāt*.

## Commonly Cited Editions

Abū ʿAmr al-Dānī (d. 444/1053), ʿUthmān b. Saʿīd. *Ǧāmiʿ al-bayān fī al-qirāʾāt al-sabʿ al-mašhūrah*, ed. Muḥammad Ṣadūq al-Ǧazāʾirī (Beirut: Dār al-Kutub al-ʿIlmiyyah, 1426/2005) \= ed. ʿAbd al-Muhaymin ʿAbd al-Salām Ṭaḥḥān, Ṭalḥah Muḥammad Tawfīq, Sāmī ʿUmar ʾIbrāhīm, and Ḫālid ʿAlī al-Ġāmidī, 4 vols. (Sharjah: Ǧāmiʿat al-Šāriqah – Kullīyat al-Dirāsāt al-ʿUlyā wa-l-Baḥṯ al-ʿIlmī, 1428/2007); hereafter cited as *ǦB*, according to the Beirut/Sharjah editions*.*  
Ibn ʿAsākir (d. 519/1125), ʿAlī b. al-Ḥasan b. Hibat Allāh Abū al-Qāsim. *Tārīḫ madīnat Dimašq*, ed. ʿUmar b. Ġarāmah al-ʿAmrawī *et al*, 75 vols. \+ Indices (Damascus: Dār al-Fikr, 1995–2000); hereafter cited as *TMD*.  
Ibn Baškuwāl (d. 578/1183), Ḫalaf b. ʿAbd al-Malik Abū al-Qāsim. *K. al-Ṣilah fī taʾrīḫ ʿulamāʾ al-Andalus*, ed. Baššār ʿAwwād Maʿruf Ibrāhīm al-Abyārī, 3 vols., reprint (Beirut: Dār al-Kitāb al-Lubnānī and Cairo: Dār al-Kitāb al-Miṣrī, N.D. \[1374/1955\]); hereafter cited as *Ṣilah*.  
Ibn Ḫayr al-Išbīlī (d. 575/1179), Muḥammad Abū Bakr. *Fahrasah mā rawāhu Ibn Ḫayr al-Išbīlī*, ed. Francesco Cordero-Zaídan and Julian Ribéra, second edition, al-Maktabah al-Andalusiyyah, reprint (Cairo: Maktabat al-Ḫānǧī, 1417/1997) \= ed. Baššār ʿAwwād Maʿrūf (Tunis: Dār al-Ġarb al-Islāmī, 2009); hereafter cited as *Fahrasah*, according to the Cordero-Zaídan and Ribera/Maʿrūf editions.  
Ibn ʿAbd al-Malik al-Marrākušī (d. 703/1303), Muḥammad b. Muḥammad Abū ʿAbd Allāh. *al-Ḏayl wa-l-takmilah li-kitābay* ‘al-Mawṣūl’ wa-‘al-Ṣilah’ (al-safarayn al-ḫāmis wa-l-sādis), ed. Iḥsān ʿAbbās, Muḥammad b. Šarīfah, and Baššār ʿAwwād Maʿrūf, 6 vols. (Tunis: Dār al-Ġarb al-Islāmī, 2012); hereafter cited as *al-Ḏayl wa-l-takmilah*.  
Kâtip Çelebî (= Ḥaǧǧī Ḫalīfah; d. 1067/1657), Muṣṭafā b. ʿAbd Allāh. *Sullam al-wuṣūl fī ṭabaqāt al-fuḥūl*, eds. Ekmeleddin İhsanoǧlu, Maḥmūd Arnaʾūṭ, and Ṣāliḥ Sadawī, 5 vols. \+ Index by Selahaddin Yugur (Istanbul: İslam Tarih, Sanat ve Kültür Araştırma Merkezi \[IRCICA\], 2010); hereafter cited as *Sullam*.  
Muḥammad b. Sulaymān al-Rūdānī (d. 1094/1683). *Ṣilat al-ḫalaf bi-mawṣūl al-salaf*, ed. Muḥammad Ḥaǧǧī (Beirut: Dār al-Ġarb al-Islāmī, 1408/1988); hereafter cited as *al-Ṣilat al-ḫalaf*.  
Sirāǧ al-Dīn al-Qazwīnī ʿUmar b. ʿAlī Abū Ḥafṣ (d. 750/1351), *Mašyaḫah*, ʿĀmir Ḥasan Ṣabrī, Silsilat al-Aǧzāʾ wa-l-Kutub al-Ḥadīthīyah 33 (Beirut: Dār al-Bašāʾir al-Islāmīyah, 1426/2005); hereafter cited as *Mašyaḫah*.